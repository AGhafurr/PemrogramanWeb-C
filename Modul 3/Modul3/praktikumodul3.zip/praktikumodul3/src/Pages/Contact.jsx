import React from "react";

const Contact = () => {
  return (
    <div>
      <h3>Hai this Contact Page</h3>
    </div>
  );
};

export default Contact;
