import React from "react";

const Aboutus = () => {
  return <h3>Are u wanna know about me??</h3>;
};

export default Aboutus;
